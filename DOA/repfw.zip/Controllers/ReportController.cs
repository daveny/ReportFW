﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Web.Mvc;
using System.Linq;
using WebApplication6.Helpers;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Web;
using System.ComponentModel;

namespace WebApplication6.Controllers
{
    public class ReportController : Controller
    {
        private readonly IDataService _dataService;
        private readonly ITemplateProcessor _templateProcessor;
        private readonly IChartRenderer _chartRenderer;

        public ReportController()
            : this(new SqlDataService(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString),
                  new TemplateProcessor(),
                  new ChartRenderer())
        {
        }

        public ReportController(IDataService dataService, ITemplateProcessor templateProcessor, IChartRenderer chartRenderer)
        {
            _dataService = dataService;
            _templateProcessor = templateProcessor;
            _chartRenderer = chartRenderer;
        }

        /// <summary>
        /// Renders a report from a template, with support for filters and form submission.
        /// </summary>
        public ActionResult RenderReport(string templateName, FormCollection formValues)
        {
            try
            {
                // Initialize the debug helper
                DebugHelper.Initialize(Server);
                DebugHelper.Log($"Starting RenderReport for template: {templateName}");

                // 1. Collect all filter values from both query string and form
                var filterValues = GetFilterValuesFromRequest();

                DebugHelper.Log($"Rendering report with {filterValues.Count} filter values");

                // Add any form values that weren't in the query string
                if (formValues != null)
                {
                    foreach (string key in formValues.Keys)
                    {
                        if (!string.IsNullOrEmpty(key) && !filterValues.ContainsKey(key))
                        {
                            filterValues[key] = formValues[key];
                        }
                    }
                }

                DebugHelper.Log("Filter values from request:");
                foreach (var kvp in filterValues)
                {
                    DebugHelper.Log($"  {kvp.Key}: {kvp.Value}");
                }

                // 2. Load the THTML template
                string templatePath = Server.MapPath($"~/Views/Reports/Templates/{templateName}.thtml");

                if (!System.IO.File.Exists(templatePath))
                {
                    DebugHelper.Log($"Template file not found: {templatePath}");
                    return Content($"<div class='alert alert-danger'>Template '{templateName}' not found.</div>");
                }

                string templateContent = System.IO.File.ReadAllText(templatePath);

                // Strip out all HTML comments so no commented‑out tokens remain
                templateContent = Regex.Replace(
                    templateContent,
                    @"<!--[\s\S]*?-->",
                    String.Empty,
                    RegexOptions.Singleline
                );

                DebugHelper.Log("Original template content (first 200 chars):");
                DebugHelper.Log(templateContent.Substring(0, Math.Min(200, templateContent.Length)));

                // 3. Process filters in the template
                string filteredContent = ProcessReportWithFilters(templateContent, filterValues);

                DebugHelper.Log("Filtered content (first 200 chars):");
                DebugHelper.Log(filteredContent.Substring(0, Math.Min(200, filteredContent.Length)));

                // 4. Process the template and render the final result
                string renderedContent = _templateProcessor.ProcessTemplate(filteredContent, _dataService, filterValues);

                // 5. Pass the content and filter values to the view
                ViewBag.ReportContent = WrapReportWithForm(renderedContent, templateName);
                ViewBag.ReportName = templateName;
                ViewBag.FilterValues = filterValues;

                // Return the view
                return View();
            }
            catch (Exception ex)
            {
                // Log the error
                DebugHelper.Log($"Error in RenderReport: {ex.Message}");
                DebugHelper.Log($"Stack trace: {ex.StackTrace}");
                return Content($"<div class='alert alert-danger'><h4>Error Rendering Report</h4><p>{ex.Message}</p><details><summary>Stack Trace</summary><pre>{ex.StackTrace}</pre></details></div>");
            }
        }

        /// <summary>
        /// Development version of the report renderer with more debugging information
        /// </summary>
        public ActionResult RenderReportDEV(string templateName)
        {
            try
            {
                // Initialize the debug helper
                DebugHelper.Initialize(Server);
                DebugHelper.Log($"Starting RenderReportDEV for template: {templateName}");

                // 1. Collect all filter values from query string
                var filterValues = GetFilterValuesFromRequest();

                DebugHelper.Log($"Rendering report with filter Year={(filterValues.ContainsKey("Year") ? filterValues["Year"] : "not set")}");

                DebugHelper.Log("Filter values from request (DEV):");
                foreach (var kvp in filterValues)
                {
                    DebugHelper.Log($"  {kvp.Key}: {kvp.Value}");
                }

                // 2. Load the THTML template from the DEV folder
                string templatePath = Server.MapPath($"~/Views/Reports/TemplatesDEV/{templateName}.thtml");
                string templateContent = System.IO.File.ReadAllText(templatePath);

                DebugHelper.Log("Original template content (DEV) (first 200 chars):");
                DebugHelper.Log(templateContent.Substring(0, Math.Min(200, templateContent.Length)));

                // 3. Process the template with filters and form
                string processedContent = ProcessReportWithFilters(templateContent, filterValues);

                DebugHelper.Log("Processed content (DEV) (first 200 chars):");
                DebugHelper.Log(processedContent.Substring(0, Math.Min(200, processedContent.Length)));

                // 4. Process the template and render the final result
                string renderedContent = _templateProcessor.ProcessTemplate(processedContent, _dataService, filterValues);

                // 5. Pass the content and filter values to the view
                ViewBag.ReportContent = WrapReportWithForm(renderedContent, templateName, true);
                ViewBag.ReportName = templateName + " (DEV)";
                ViewBag.FilterValues = filterValues;
                ViewBag.IsDev = true;

                // Return the view (reuse the same view as regular reports)
                return View("RenderReport");
            }
            catch (Exception ex)
            {
                // Add logging here
                DebugHelper.Log($"Error in RenderReportDEV: {ex.Message}");
                DebugHelper.Log($"Stack trace: {ex.StackTrace}");
                return Content($"<div class='alert alert-danger'><h4>Error Rendering DEV Report</h4><p>{ex.Message}</p><details><summary>Stack Trace</summary><pre>{ex.StackTrace}</pre></details></div>");
            }
        }

        /// <summary>
        /// Wraps the report content in a form with a filter panel and apply button
        /// </summary>
        private string WrapReportWithForm(string reportContent, string templateName, bool isDev = false)
        {
            // Extract any filter controls from the report
            var filterControls = ExtractFilterControls(reportContent);

            if (filterControls.Count == 0)
            {
                // If no filters, just return the original content
                return reportContent;
            }

            // Build a wrapper with filters in a collapsible panel
            string actionUrl = isDev ?
                Url.Action("RenderReportDEV", new { templateName }) :
                Url.Action("RenderReport", new { templateName });

            string html = $@"
<form id='reportForm' action='{actionUrl}' method='get'>
    <div class='card mb-4 filter-panel'>
        <div class='card-header d-flex justify-content-between align-items-center bg-light'>
            <h3 class='mb-0'>
                <button class='btn btn-link' type='button' data-bs-toggle='collapse' data-bs-target='#filterCollapse' 
                        aria-expanded='true' aria-controls='filterCollapse'>
                    Filter Options <span class='filter-count badge bg-primary'>{filterControls.Count}</span>
                </button>
            </h3>
            <div>
                <button type='button' id='resetFilters' class='btn btn-secondary me-2'>Reset Filters</button>
                <button type='submit' class='btn btn-primary'>Apply Filters</button>
            </div>
        </div>
        
        <div id='filterCollapse' class='collapse show'>
            <div class='card-body'>
                <div class='row'>";

            // Add each filter control in its own column
            int colWidth = Math.Max(3, Math.Min(12, 12 / Math.Min(filterControls.Count, 4))); // 3, 4, 6, or 12 depending on count

            foreach (var filter in filterControls)
            {
                html += $@"
                <div class='col-md-{colWidth} mb-3'>
                    {filter}
                </div>";
            }

            html += @"
                </div>
            </div>
        </div>
    </div>
    
    <div class='report-content'>
";
            // Add the cleaned report content
            html += CleanupReportContent(reportContent);

            html += @"
    </div>
</form>
";
            return html;
        }

        /// <summary>
        /// Process the template by replacing filter tokens and handling parameters
        /// </summary>
        private string ProcessReportWithFilters(string templateContent, Dictionary<string, string> filterValues)
        {
            // Remove the template-content wrapper if present
            templateContent = templateContent.Replace("<template-content>", "").Replace("</template-content>", "");

            // Process filters using the FilterProcessor helper
            string processedContent = FilterProcessor.ProcessFilters(templateContent, filterValues);

            return processedContent;
        }

        /// <summary>
        /// Extracts all filter controls from the rendered report content
        /// </summary>
        private List<string> ExtractFilterControls(string reportContent)
        {
            var filters = new List<string>();

            // Look for div elements with class "filter-component"
            string pattern = @"<div\s+class=['""]filter-component['""].*?>(.*?)</div>";
            RegexOptions options = RegexOptions.Singleline;

            foreach (Match match in Regex.Matches(reportContent, pattern, options))
            {
                // Take the whole filter component div
                filters.Add(match.Value);
            }

            return filters;
        }

        /// <summary>
        /// Remove filter components from the report content since they're moved to the filter panel
        /// </summary>
        private string CleanupReportContent(string reportContent)
        {
            // Remove filter component divs
            string pattern = @"<div\s+class=['""]filter-component['""].*?</div>";
            RegexOptions options = RegexOptions.Singleline;

            return Regex.Replace(reportContent, pattern, "", options);
        }

        /// <summary>
        /// API endpoint to get filter data from a database query
        /// </summary>
        [HttpGet]
        public ActionResult GetFilterData(string query, string valueField, string textField)
        {
            try
            {
                DebugHelper.Log($"GetFilterData called with query: {query}");

                // Execute the query
                DataTable data = _dataService.ExecuteQuery(query);
                DebugHelper.Log($"Query returned {data.Rows.Count} rows");

                // Convert to list of {value, text} objects
                var result = new List<object>();

                foreach (DataRow row in data.Rows)
                {
                    string value = row[valueField].ToString();
                    string text = string.IsNullOrEmpty(textField) ? value : row[textField].ToString();

                    result.Add(new { value, text });
                }

                return Json(result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                // Return error (could be improved with proper error handling)
                DebugHelper.Log($"Error in GetFilterData: {ex.Message}");
                return Json(new { error = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// API endpoint to update a chart with new filter values
        /// </summary>
        [HttpPost]
        public ActionResult UpdateChart()
        {
            try
            {
                DebugHelper.Initialize(Server);

                // Get the raw token from the request
                string token = Request.Form["token"];
                DebugHelper.Log($"UpdateChart called with token length: {token?.Length ?? 0}");

                if (string.IsNullOrEmpty(token))
                {
                    return Content("<div class='alert alert-danger'>Error: Missing chart token</div>");
                }

                // Get the filter values from the request
                var filterValues = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                // Extract filter values from the form
                foreach (string key in Request.Form.AllKeys)
                {
                    if (key != "token" && key != "filterValues")
                    {
                        filterValues[key] = Request.Form[key];
                    }
                }

                // If filter values were passed as a JSON object, try to parse and use them
                if (Request.Form["filterValues"] != null)
                {
                    try
                    {
                        var jsonValues = Newtonsoft.Json.JsonConvert.DeserializeObject<Dictionary<string, string>>(Request.Form["filterValues"]);
                        if (jsonValues != null)
                        {
                            foreach (var kvp in jsonValues)
                            {
                                filterValues[kvp.Key] = kvp.Value;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        DebugHelper.Log($"Error parsing filterValues as JSON: {ex.Message}");
                    }
                }

                // Process the token (which contains the chart instructions)
                var instructionParser = new InstructionParser();

                // Extract the instruction content between {{ and }}
                string instructionContent;
                if (token.StartsWith("{{") && token.EndsWith("}}"))
                {
                    instructionContent = token.Substring(2, token.Length - 4).Trim();
                }
                else
                {
                    instructionContent = token.Trim();
                }

                DebugHelper.Log($"Instruction content: {instructionContent.Substring(0, Math.Min(100, instructionContent.Length))}...");

                var instructions = instructionParser.ParseInstructions(instructionContent);

                // Debug output of parsed instructions
                DebugHelper.Log($"Parsed {instructions.Count} instructions from token");
                foreach (var key in instructions.Keys)
                {
                    DebugHelper.Log($"  {key}: {(instructions[key]?.Length > 50 ? instructions[key].Substring(0, 50) + "..." : instructions[key])}");
                }

                // Execute the query with filter values applied
                if (!instructions.ContainsKey("query") || string.IsNullOrEmpty(instructions["query"]))
                {
                    DebugHelper.Log("Error: Missing query parameter in instructions");
                    return Content("<div class='alert alert-danger'>Error: Missing required 'query' parameter</div>");
                }

                string queryText = instructions["query"];
                DebugHelper.Log($"Query: {queryText}");

                // Debug output of filter values
                DebugHelper.Log($"Received {filterValues?.Count ?? 0} filter values:");
                if (filterValues != null)
                {
                    foreach (var kvp in filterValues)
                    {
                        DebugHelper.Log($"  {kvp.Key}: {kvp.Value}");
                    }
                }

                // Create a data table to hold our results
                DataTable data = new DataTable();

                using (SqlConnection connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
                {
                    connection.Open();

                    // Create the command with parameterized query
                    using (SqlCommand command = new SqlCommand(queryText, connection))
                    {
                        // Add parameters
                        if (filterValues != null)
                        {
                            foreach (var filter in filterValues)
                            {
                                string paramName = "@" + filter.Key;
                                string paramValue = filter.Value;

                                // Skip empty values - treat as NULL
                                if (string.IsNullOrEmpty(paramValue))
                                {
                                    command.Parameters.AddWithValue(paramName, DBNull.Value);
                                    DebugHelper.Log($"Added NULL parameter {paramName}");
                                    continue;
                                }

                                // Try to parse as number for correct SQL typing
                                if (int.TryParse(paramValue, out int intValue))
                                {
                                    command.Parameters.AddWithValue(paramName, intValue);
                                    DebugHelper.Log($"Added parameter {paramName} as int: {intValue}");
                                }
                                else if (decimal.TryParse(paramValue, out decimal decValue))
                                {
                                    command.Parameters.AddWithValue(paramName, decValue);
                                    DebugHelper.Log($"Added parameter {paramName} as decimal: {decValue}");
                                }
                                else if (DateTime.TryParse(paramValue, out DateTime dateValue))
                                {
                                    command.Parameters.AddWithValue(paramName, dateValue);
                                    DebugHelper.Log($"Added parameter {paramName} as date: {dateValue}");
                                }
                                else
                                {
                                    command.Parameters.AddWithValue(paramName, paramValue);
                                    DebugHelper.Log($"Added parameter {paramName} as string: {paramValue}");
                                }
                            }
                        }

                        // Execute and fill the data table
                        DebugHelper.Log("Executing SQL query...");
                        try
                        {
                            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                            {
                                adapter.Fill(data);
                            }
                            DebugHelper.Log($"Query executed successfully, returned {data.Rows.Count} rows");
                        }
                        catch (Exception ex)
                        {
                            DebugHelper.Log($"SQL Error: {ex.Message}");
                            return Content($"<div class='alert alert-danger'>SQL Error: {ex.Message}</div>");
                        }
                    }
                }

                // Render the chart based on the data and instructions
                string chartHtml = _chartRenderer.RenderChart(data, instructions);
                DebugHelper.Log($"Chart rendered, HTML length: {chartHtml?.Length ?? 0}");

                return Content(chartHtml);
            }
            catch (Exception ex)
            {
                DebugHelper.Log($"Error in UpdateChart: {ex.Message}");
                DebugHelper.Log($"Stack trace: {ex.StackTrace}");
                return Content($"<div class='alert alert-danger'>Error updating chart: {ex.Message}</div>");
            }
        }

        /// <summary>
        /// Helper method to extract filter values from the request
        /// </summary>
        private Dictionary<string, string> GetFilterValuesFromRequest()
        {
            var filterValues = new Dictionary<string, string>();

            // First check for values in the query string
            foreach (string key in Request.QueryString.Keys)
            {
                if (key != null)
                {
                    string value = Request.QueryString[key];
                    filterValues[key] = value;
                }
            }

            // Then check for values in the form data (POST)
            if (Request.Form.Keys.Count > 0)
            {
                foreach (string key in Request.Form.Keys)
                {
                    if (key != null)
                    {
                        string value = Request.Form[key];
                        filterValues[key] = value;
                    }
                }
            }

            return filterValues;
        }

        /// <summary>
        /// Helper method to get all report templates
        /// </summary>
        public static List<string> GetReportTemplates()
        {
            try
            {
                string templatePath = System.Web.Hosting.HostingEnvironment.MapPath("~/Views/Reports/Templates");
                if (!Directory.Exists(templatePath))
                {
                    System.Diagnostics.Debug.WriteLine($"Templates directory does not exist: {templatePath}");
                    return new List<string>();
                }

                // Get all .thtml files, extract their names without extension, and sort alphabetically
                var templates = Directory.GetFiles(templatePath, "*.thtml")
                    .Select(Path.GetFileNameWithoutExtension)
                    .OrderBy(name => name) // Sort alphabetically
                    .ToList();

                System.Diagnostics.Debug.WriteLine($"Found {templates.Count} templates in {templatePath}");
                return templates;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in GetReportTemplates: {ex.Message}");
                // Return empty list if there's an error
                return new List<string>();
            }
        }

        /// <summary>
        /// Helper method to get DEV report templates (sorted alphabetically)
        /// </summary>
        public static List<string> GetReportTemplatesDEV()
        {
            try
            {
                string templatePath = System.Web.Hosting.HostingEnvironment.MapPath("~/Views/Reports/TemplatesDEV");
                if (!Directory.Exists(templatePath))
                {
                    System.Diagnostics.Debug.WriteLine($"TemplatesDEV directory does not exist: {templatePath}");
                    return new List<string>();
                }

                // Get all .thtml files, extract their names without extension, and sort alphabetically
                var templates = Directory.GetFiles(templatePath, "*.thtml")
                    .Select(Path.GetFileNameWithoutExtension)
                    .OrderBy(name => name) // Sort alphabetically
                    .ToList();

                System.Diagnostics.Debug.WriteLine($"Found {templates.Count} DEV templates in {templatePath}");
                return templates;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error in GetReportTemplatesDEV: {ex.Message}");
                // Return empty list if there's an error
                return new List<string>();
            }
        }
    }
}