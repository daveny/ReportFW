﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace WebApplication6.Helpers
{
    public class FilterProcessor
    {
        // Updated regex patterns for filter extraction - specifically handle the format as shown
        private static readonly string FilterPattern = @"\{\{filter\s+(.*?)\}\}";
        private static readonly string ParamPattern = @"@\w+";

        public static string ProcessFilters(string templateContent, Dictionary<string, string> filterValues)
        {
            DebugHelper.Log($"Starting filter processing with pattern: {FilterPattern}");
            DebugHelper.Log($"Sample of content: {templateContent.Substring(0, Math.Min(200, templateContent.Length))}");

            // Find all filter declarations
            MatchCollection filterMatches = Regex.Matches(templateContent, FilterPattern);
            DebugHelper.Log($"Found {filterMatches.Count} filter matches");

            // Process each filter
            foreach (Match match in filterMatches)
            {
                string filterDeclaration = match.Value;
                string filterContent = match.Groups[1].Value.Trim();

                DebugHelper.Log($"Processing filter: {filterDeclaration}");

                // Parse filter instructions
                var filterInstructions = ParseFilterInstructions(filterContent);

                // Render the filter control based on type
                string renderedFilter = RenderFilterControl(filterInstructions, filterValues);

                // Replace the token with the rendered control
                templateContent = templateContent.Replace(filterDeclaration, renderedFilter);
                DebugHelper.Log("Filter replaced with rendered control");
            }

            // After rendering all filters, process queries that might depend on filter values
            DebugHelper.Log("Processing parameterized queries");
            templateContent = ProcessParameterizedQueries(templateContent, filterValues);

            return templateContent;
        }

        private static Dictionary<string, string> ParseFilterInstructions(string filterContent)
        {
            var instructions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            // Split by semicolons that are not inside quotes
            List<string> parts = new List<string>();
            bool inQuotes = false;
            int startIndex = 0;

            for (int i = 0; i < filterContent.Length; i++)
            {
                char c = filterContent[i];

                if (c == '"')
                {
                    // Toggle quote state, but only if not escaped
                    if (i == 0 || filterContent[i - 1] != '\\')
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ';' && !inQuotes)
                {
                    // Found a semicolon outside quotes - split here
                    parts.Add(filterContent.Substring(startIndex, i - startIndex).Trim());
                    startIndex = i + 1;
                }
            }

            // Add the last part
            if (startIndex < filterContent.Length)
            {
                parts.Add(filterContent.Substring(startIndex).Trim());
            }

            DebugHelper.Log($"Filter parts: {string.Join(" | ", parts)}");

            // Process each part as a key-value pair
            foreach (string part in parts)
            {
                int equalsPos = part.IndexOf('=');
                if (equalsPos > 0)
                {
                    string key = part.Substring(0, equalsPos).Trim();
                    string value = part.Substring(equalsPos + 1).Trim();

                    // Remove surrounding quotes if present
                    if (value.StartsWith("\"") && value.EndsWith("\""))
                    {
                        value = value.Substring(1, value.Length - 2);
                    }

                    // Convert key to lowercase for case-insensitive comparison
                    instructions[key.ToLower()] = value;
                    DebugHelper.Log($"Parsed filter instruction: {key}={value}");
                }
            }

            return instructions;
        }

        private static string RenderFilterControl(Dictionary<string, string> instructions, Dictionary<string, string> filterValues)
        {
            string type = instructions.ContainsKey("type") ? instructions["type"].ToLower() : "dropdown";
            string id = instructions.ContainsKey("id") ? instructions["id"] : "filter_" + Guid.NewGuid().ToString("N");
            string label = instructions.ContainsKey("label") ? instructions["label"] : "Filter";
            string paramName = instructions.ContainsKey("param") ? instructions["param"] : id;
            string defaultValue = instructions.ContainsKey("default") ? instructions["default"] : "";
            string dataSource = instructions.ContainsKey("dataSource") ? instructions["dataSource"] : "";
            string valueField = instructions.ContainsKey("valueField") ? instructions["valueField"] : "";
            string textField = instructions.ContainsKey("textField") ? instructions["textField"] : valueField;

            // Handle values in dropdown
            string values = instructions.ContainsKey("values") ? instructions["values"] : "";

            string[] affectedElements = instructions.ContainsKey("affects")
                ? instructions["affects"].Split(',').Select(s => s.Trim()).ToArray()
                : new string[0];

            // Check if a filter value has been provided (from URL or session)
            // Log both values for debugging
            DebugHelper.Log($"Filter {paramName}: default={defaultValue}, request value={(filterValues.ContainsKey(paramName) ? filterValues[paramName] : "not present")}");

            string currentValue = filterValues.ContainsKey(paramName) ? filterValues[paramName] : defaultValue;

            // Log the final value being used
            DebugHelper.Log($"Using value for {paramName}: {currentValue}");

            DebugHelper.Log($"Rendering filter control: type={type}, id={id}, param={paramName}");

            // HTML for the filter control
            string html = $"<div class='filter-component mb-3' data-filter-id='{id}' data-param-name='{paramName}'>";
            html += $"<label for='{id}' class='form-label'>{label}</label>";

            switch (type)
            {
                case "dropdown":
                    if (!string.IsNullOrEmpty(values))
                    {
                        html += RenderStaticDropdownFilter(id, paramName, currentValue, values, affectedElements);
                    }
                    else
                    {
                        html += RenderDropdownFilter(id, paramName, currentValue, dataSource, valueField, textField, affectedElements);
                    }
                    break;

                case "button":
                    html += RenderButtonFilter(id, paramName, currentValue, instructions, affectedElements);
                    break;

                case "calendar":
                    html += RenderCalendarFilter(id, paramName, currentValue, affectedElements);
                    break;

                case "text":
                    html += RenderTextFilter(id, paramName, currentValue, affectedElements);
                    break;

                default:
                    html += RenderDropdownFilter(id, paramName, currentValue, dataSource, valueField, textField, affectedElements);
                    break;
            }

            html += "</div>";

            DebugHelper.Log($"Rendered filter HTML (first 100 chars): {html.Substring(0, Math.Min(100, html.Length))}");

            return html;
        }

        private static string RenderStaticDropdownFilter(
    string id, string paramName, string currentValue, string values, string[] affectedElements)
        {
            // Parse values
            string[] options = values.Split(',').Select(v => v.Trim().Trim('"', '\'')).ToArray();

            DebugHelper.Log($"Rendering static dropdown with options: {string.Join(",", options)} and currentValue: {currentValue}");

            // Base HTML for select element
            string html = $"<select id='{id}' name='{paramName}' class='form-control filter-dropdown' ";

            // Add data attributes for affected elements
            if (affectedElements.Length > 0)
            {
                html += $"data-affects='{string.Join(",", affectedElements)}' ";
            }

            html += ">";

            // Add a placeholder option
            html += $"<option value=''>Select {paramName}</option>";

            // Add each option
            foreach (string option in options)
            {
                // Explicitly check if this option matches the current value
                bool isSelected = option == currentValue;
                html += $"<option value='{option}'{(isSelected ? " selected" : "")}>{option}</option>";

                // Add debugging to see what's selected
                if (isSelected)
                {
                    DebugHelper.Log($"Selected option: {option}");
                }
            }

            html += "</select>";

            return html;
        }

        private static string RenderDropdownFilter(
            string id, string paramName, string currentValue, string dataSource,
            string valueField, string textField, string[] affectedElements)
        {
            // Base HTML for select element
            string html = $"<select id='{id}' name='{paramName}' class='form-control filter-dropdown' ";

            // Add data attributes for affected elements
            if (affectedElements.Length > 0)
            {
                html += $"data-affects='{string.Join(",", affectedElements)}' ";
            }

            html += ">";

            // If a dataSource is provided, we'll load the options via AJAX
            // Otherwise, we'll need to populate static options from the instructions
            if (!string.IsNullOrEmpty(dataSource))
            {
                // Add a placeholder option
                html += $"<option value=''>Select {paramName}</option>";

                // Will be populated via AJAX
                html += $"</select>";

                // Add script to load options
                html += $@"
<script>
    $(document).ready(function() {{
        // Load dropdown options via AJAX
        $.ajax({{
            url: '/Report/GetFilterData',
            type: 'GET',
            data: {{ 
                query: '{HttpUtility.JavaScriptStringEncode(dataSource)}',
                valueField: '{HttpUtility.JavaScriptStringEncode(valueField)}',
                textField: '{HttpUtility.JavaScriptStringEncode(textField)}'
            }},
            success: function(data) {{
                var select = $('#{id}');
                
                // Add options
                $.each(data, function(i, item) {{
                    var option = $('<option>').val(item.value).text(item.text);
                    if (item.value == '{HttpUtility.JavaScriptStringEncode(currentValue)}') {{
                        option.prop('selected', true);
                    }}
                    select.append(option);
                }});
                
                // Trigger change to refresh dependent elements
                select.trigger('change');
            }},
            error: function(error) {{
                console.error('Failed to load filter options:', error);
                $('#{id}').append('<option>Error loading options</option>');
            }}
        }});
    }});
</script>";
            }
            else
            {
                // No data source provided, this would need static options
                html += $"<option value=''>Select {paramName}</option>";
                html += "</select>";
            }

            return html;
        }

        private static string RenderButtonFilter(
            string id, string paramName, string currentValue,
            Dictionary<string, string> instructions, string[] affectedElements)
        {
            string[] buttonValues = instructions.ContainsKey("values")
                ? instructions["values"].Split(',').Select(s => s.Trim()).ToArray()
                : new[] { "Yes", "No" };

            string[] buttonLabels = instructions.ContainsKey("labels")
                ? instructions["labels"].Split(',').Select(s => s.Trim()).ToArray()
                : buttonValues;

            // Ensure we have enough labels for all values
            while (buttonLabels.Length < buttonValues.Length)
            {
                buttonLabels = buttonLabels.Concat(new[] { buttonValues[buttonLabels.Length] }).ToArray();
            }

            DebugHelper.Log($"Rendering button filter with values: {string.Join(",", buttonValues)}");

            // Build button group
            string html = $"<div class='btn-group filter-button-group' role='group' aria-label='{paramName}' ";

            // Add data attributes for affected elements
            if (affectedElements.Length > 0)
            {
                html += $"data-affects='{string.Join(",", affectedElements)}' ";
            }

            html += ">";

            // Add individual buttons
            for (int i = 0; i < buttonValues.Length; i++)
            {
                string value = buttonValues[i];
                string label = buttonLabels[i];
                bool isActive = value == currentValue;

                html += $@"
                <button type='button' 
                        class='btn {(isActive ? "btn-primary" : "btn-secondary")} filter-button' 
                        data-filter-id='{id}' 
                        data-param-name='{paramName}' 
                        data-value='{value}'>
                    {label}
                </button>";
            }

            html += "</div>";

            return html;
        }

        private static string RenderCalendarFilter(string id, string paramName, string currentValue, string[] affectedElements)
        {
            // Add date picker input
            string html = $@"<input type='text' id='{id}' name='{paramName}' class='form-control datepicker' ";

            // Add current value if available
            if (!string.IsNullOrEmpty(currentValue))
            {
                html += $"value='{currentValue}' ";
            }

            // Add data attributes for affected elements
            if (affectedElements.Length > 0)
            {
                html += $"data-affects='{string.Join(",", affectedElements)}' ";
            }

            html += ">";

            // Add datepicker initialization script
            html += $@"
<script>
    $(document).ready(function() {{
        $('#{id}').datepicker({{
            format: 'yyyy-mm-dd',
            autoclose: true
        }});
    }});
</script>";

            return html;
        }

        private static string RenderTextFilter(string id, string paramName, string currentValue, string[] affectedElements)
        {
            string html = $@"<div class='input-group'>
                <input type='text' id='{id}' name='{paramName}' class='form-control filter-text' ";

            // Add current value if available
            if (!string.IsNullOrEmpty(currentValue))
            {
                html += $"value='{currentValue}' ";
            }

            // Add data attributes for affected elements
            if (affectedElements.Length > 0)
            {
                html += $"data-affects='{string.Join(",", affectedElements)}' ";
            }

            html += @">
                <div class='input-group-append'>
                    <button class='btn btn-outline-secondary filter-apply-btn' type='button'>Apply</button>
                </div>
            </div>";

            return html;
        }

        public static string ProcessParameterizedQueries(string templateContent, Dictionary<string, string> filterValues)
        {
            // Find all tokens that contain queries
            string pattern = @"\{\{((?:[^{}]|(?<Open>\{)|(?<-Open>\}))+(?(Open)(?!)))\}\}";
            MatchCollection matches = Regex.Matches(templateContent, pattern);

            DebugHelper.Log($"Found {matches.Count} tokens with possible queries");

            foreach (Match match in matches)
            {
                string token = match.Value;
                string instructionContent = match.Groups[1].Value.Trim();

                // Skip filter tokens
                if (instructionContent.StartsWith("filter"))
                {
                    DebugHelper.Log($"Skipping filter token: {token.Substring(0, Math.Min(50, token.Length))}...");
                    continue;
                }

                // Check if this token contains a query
                if (instructionContent.Contains("query="))
                {
                    DebugHelper.Log($"Processing query token: {token.Substring(0, Math.Min(50, token.Length))}...");

                    // Extract the query string
                    int queryStart = instructionContent.IndexOf("query=") + 6;
                    int queryEnd;

                    if (instructionContent[queryStart] == '"')
                    {
                        // Query is quoted
                        queryStart++; // Skip the opening quote
                        queryEnd = instructionContent.IndexOf('"', queryStart);
                    }
                    else
                    {
                        // Query is not quoted, find the next semicolon
                        queryEnd = instructionContent.IndexOf(';', queryStart);
                        if (queryEnd == -1)
                        {
                            queryEnd = instructionContent.Length;
                        }
                    }

                    if (queryEnd > queryStart)
                    {
                        string query = instructionContent.Substring(queryStart, queryEnd - queryStart);
                        DebugHelper.Log($"Extracted query: {query.Substring(0, Math.Min(100, query.Length))}...");

                        // Find parameters in the query (@ParamName)
                        string ParamPattern = @"@\w+";
                        MatchCollection paramMatches = Regex.Matches(query, ParamPattern);
                        DebugHelper.Log($"Found {paramMatches.Count} parameters in query");

                        // Check if this query contains parameters without values - use a HashSet to remove duplicates
                        bool needsParams = false;
                        var uniqueParamNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                        foreach (Match paramMatch in paramMatches)
                        {
                            string paramName = paramMatch.Value.Substring(1); // Remove @ prefix

                            // Only add if not already in the set (case-insensitive)
                            if (!uniqueParamNames.Contains(paramName) &&
                                !filterValues.ContainsKey(paramName) &&
                                !query.Contains($"IS NULL OR {paramMatch.Value} ="))
                            {
                                uniqueParamNames.Add(paramName);
                                DebugHelper.Log($"Missing parameter value for: {paramName}");
                                needsParams = true;
                            }
                        }

                        // Create a list of unique needed parameters
                        var neededParams = uniqueParamNames.ToList();

                        // Add data-needs-params attribute if needed
                        if (needsParams)
                        {
                            // Get ID from instructions if available
                            string id = "";
                            int idStart = instructionContent.IndexOf("id=");
                            if (idStart >= 0)
                            {
                                idStart += 3;
                                int idEnd;

                                if (instructionContent[idStart] == '"')
                                {
                                    idStart++; // Skip opening quote
                                    idEnd = instructionContent.IndexOf('"', idStart);
                                }
                                else
                                {
                                    idEnd = instructionContent.IndexOf(';', idStart);
                                    if (idEnd == -1)
                                    {
                                        idEnd = instructionContent.Length;
                                    }
                                }

                                if (idEnd > idStart)
                                {
                                    id = instructionContent.Substring(idStart, idEnd - idStart);
                                }
                            }

                            // If no ID found, generate one
                            if (string.IsNullOrEmpty(id))
                            {
                                id = "chart_" + Guid.NewGuid().ToString("N");
                            }

                            DebugHelper.Log($"Creating placeholder for chart {id} waiting for params: {string.Join(",", neededParams)}");

                            // IMPORTANT: Store the encoded token as a data attribute, using BASE64 encoding
                            string base64Token = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(token));

                            // Create placeholder with needed params - ensuring we BASE64 encode the token to avoid issues
                            string placeholder = $@"<div id='{id}_container' class='chart-placeholder' 
                                                data-token-b64='{base64Token}'
                                                data-needs-params='{string.Join(",", neededParams)}'
                                                data-params-count='{neededParams.Count}'>
                                <div class='alert alert-info'>
                                    Please select {string.Join(", ", neededParams.Select(p => $"<strong>{p}</strong>"))}
                                </div>
                            </div>";

                            // Replace the token with the placeholder
                            templateContent = templateContent.Replace(token, placeholder);
                        }
                        else
                        {
                            // Get the distinct parameter names
                            var uniqueParams = new HashSet<string>();
                            foreach (Match paramMatch in paramMatches)
                            {
                                string paramName = paramMatch.Value.Substring(1); // Remove @ prefix
                                uniqueParams.Add(paramName);
                            }

                            // Now replace each parameter once, hitting all occurrences at the same time
                            foreach (string paramName in uniqueParams)
                            {
                                if (filterValues.ContainsKey(paramName))
                                {
                                    string paramValue = filterValues[paramName];
                                    string paramPattern = "@" + paramName;
                                    DebugHelper.Log($"Replacing all occurrences of {paramPattern} with '{paramValue}'");

                                    // Update the query parameter - replace all occurrences at once
                                    string updatedQuery = query;

                                    // Special handling for SQL parameters
                                    if (string.IsNullOrEmpty(paramValue))
                                    {
                                        // Empty value becomes NULL in SQL
                                        updatedQuery = Regex.Replace(updatedQuery, paramPattern + "\\b", "NULL");
                                    }
                                    else
                                    {
                                        // Non-empty value becomes quoted string in SQL
                                        updatedQuery = Regex.Replace(updatedQuery, paramPattern + "\\b", $"'{paramValue}'");
                                    }

                                    // Replace in the instructionContent
                                    instructionContent = instructionContent.Substring(0, queryStart) +
                                                         updatedQuery +
                                                         instructionContent.Substring(queryEnd);

                                    // Update query for next parameter
                                    query = updatedQuery;
                                }
                            }

                            // Update the full token with the modified instructions
                            string updatedToken = "{{" + instructionContent + "}}";
                            templateContent = templateContent.Replace(token, updatedToken);
                            DebugHelper.Log("Token updated with parameter values");
                        }
                    }
                }
            }

            return templateContent;
        }
    }
}