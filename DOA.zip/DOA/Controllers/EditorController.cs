﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using Core.Helpers;
using Core.Models;

namespace Core.Controllers
{
    [Authorize]
    public class EditorController : Controller
    {
        private readonly ITemplateProcessor _templateProcessor;
        private readonly IDataService _dataService;

        // Paraméter nélküli ctor (MVC tudja példányosítani DI nélkül is)
        public EditorController()
        {
            var cs = ConfigurationManager.ConnectionStrings["DefaultConnection"]?.ConnectionString ?? "";
            _dataService = new SqlDataService(cs);
            _templateProcessor = new TemplateProcessor();
        }

        // Opcionális DI-ctor
        public EditorController(ITemplateProcessor templateProcessor, IDataService dataService)
        {
            _templateProcessor = templateProcessor ?? new TemplateProcessor();
            _dataService = dataService ?? new SqlDataService(ConfigurationManager.ConnectionStrings["DefaultConnection"]?.ConnectionString ?? "");
        }

        [HttpGet]
        public ActionResult Index() => View();

        private string MetricsRoot
        {
            get
            {
                var root = Server.MapPath("~/Views/Metrics/Templates");
                Directory.CreateDirectory(root);
                return root;
            }
        }

        [HttpGet]
        public ActionResult LoadMetric(string fileName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(fileName))
                    return new HttpStatusCodeResult(400, "Missing fileName");

                var safe = Path.GetFileName(fileName);
                var path = Path.Combine(MetricsRoot, safe);

                if (!System.IO.File.Exists(path))
                    return HttpNotFound("File not found");

                var txt = System.IO.File.ReadAllText(path);
                return Content(txt, "text/plain");
            }
            catch (Exception ex)
            {
                DebugHelper.Log($"LoadMetric ERROR: {ex}");
                return new HttpStatusCodeResult(500, ex.Message);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)] // a .thtml tartalomban lehet HTML-szerű szöveg
        public JsonResult SaveMetric(string fileName, string content)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(fileName))
                    return Json(new { success = false, message = "fileName is required" });

                if (!fileName.EndsWith(".thtml", StringComparison.OrdinalIgnoreCase))
                    fileName += ".thtml";

                var safe = Path.GetFileName(fileName);
                var path = Path.Combine(MetricsRoot, safe);

                System.IO.File.WriteAllText(path, content ?? string.Empty);
                DebugHelper.Log($"SaveMetric OK: {path} (len={content?.Length ?? 0})");

                return Json(new { success = true, message = $"Metric saved: {safe}" });
            }
            catch (Exception ex)
            {
                DebugHelper.Log($"SaveMetric ERROR: {ex}");
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult DeleteMetric(string fileName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(fileName))
                    return Json(new { success = false, message = "fileName is required" });

                if (!fileName.EndsWith(".thtml", StringComparison.OrdinalIgnoreCase))
                    fileName += ".thtml";

                var safe = Path.GetFileName(fileName);
                var path = Path.Combine(MetricsRoot, safe);

                if (!System.IO.File.Exists(path))
                    return Json(new { success = false, message = "File not found" });

                System.IO.File.Delete(path);
                DebugHelper.Log($"DeleteMetric OK: {path}");
                return Json(new { success = true, message = $"Metric deleted: {safe}" });
            }
            catch (Exception ex)
            {
                DebugHelper.Log($"DeleteMetric ERROR: {ex}");
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)] // a .thtml tartalomban lehet HTML-szerű szöveg
        public ContentResult RenderPreview(string thtmlCode)
        {
            try
            {
                DebugHelper.Log("--- RenderPreview START ---");

                // Paraméterek összegyűjtése string->string dictionary-be
                var exclude = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                { "__RequestVerificationToken", "thtmlCode" };

                var parameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                foreach (var k in Request.QueryString.AllKeys.Where(k => k != null))
                    if (!exclude.Contains(k)) parameters[k] = Request.QueryString[k];

                foreach (var k in Request.Form.AllKeys.Where(k => k != null))
                    if (!exclude.Contains(k)) parameters[k] = Request.Form[k];

                var html = _templateProcessor.ProcessTemplate(thtmlCode ?? string.Empty, _dataService, parameters);

                DebugHelper.Log("--- RenderPreview END (Success) ---");
                return Content(html, "text/html");
            }
            catch (Exception ex)
            {
                DebugHelper.Log($"RenderPreview ERROR: {ex.Message}\n{ex.StackTrace}");
                DebugHelper.Log("--- RenderPreview END (Error) ---");
                var safe = System.Web.HttpUtility.HtmlEncode(ex.Message);
                return Content($"<div class='alert alert-danger'>Error rendering preview: {safe}</div>", "text/html");
            }
        }

        [HttpGet]
        public ActionResult ManagedSegmentDebug(string viewAs = null)
        {
            const string managedSegmentParam = "managedSegment";
            var adminSeparators = new[] { ';', ',', '|' };

            var pattern = ConfigurationManager.AppSettings["ManagedSegmentGroupPattern"] ?? @"EUR\app_eur_contar_*";
            var adminRaw = ConfigurationManager.AppSettings["ManagedSegmentAdminGroups"] ?? string.Empty;

            var adminGroups = adminRaw
                .Split(adminSeparators, StringSplitOptions.RemoveEmptyEntries)
                .Select(g => g.Trim())
                .Where(g => !string.IsNullOrEmpty(g))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(g => g, StringComparer.OrdinalIgnoreCase)
                .ToList();

            var signedInAccount = User?.Identity?.Name ?? string.Empty;
            var trimmedViewAs = string.IsNullOrWhiteSpace(viewAs) ? null : viewAs.Trim();

            string lookupError = null;
            IReadOnlyList<string> groupNames;
            ManagedSegmentInfo info;

            if (string.IsNullOrWhiteSpace(trimmedViewAs))
            {
                groupNames = ManagedSegmentHelper.GetUserGroupNames();
                info = ManagedSegmentHelper.GetManagedSegmentInfo();
            }
            else
            {
                groupNames = ManagedSegmentHelper.GetUserGroupNames(trimmedViewAs, out lookupError);
                info = ManagedSegmentHelper.GetManagedSegmentInfoForGroups(groupNames);
            }

            var resolvedParameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var combinedValue = ManagedSegmentHelper.ResolveValue(resolvedParameters, managedSegmentParam, null, info) ?? string.Empty;
            resolvedParameters.TryGetValue(managedSegmentParam + "_admin", out var adminFlag);

            var model = new ManagedSegmentDebugViewModel
            {
                Pattern = pattern,
                AdminGroups = adminGroups,
                AllGroups = groupNames,
                Info = info,
                CombinedValue = combinedValue,
                AdminFlag = string.IsNullOrWhiteSpace(adminFlag) ? "0" : adminFlag,
                LookupAccountName = trimmedViewAs ?? string.Empty,
                EffectiveAccountName = string.IsNullOrWhiteSpace(trimmedViewAs) ? signedInAccount : trimmedViewAs,
                SignedInAccountName = signedInAccount,
                LookupError = lookupError
            };

            return View("ManagedSegmentDebug", model);
        }
    }
}
