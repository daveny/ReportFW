﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;

namespace Core.Helpers
{
    public sealed class ManagedSegmentOption
    {
        public ManagedSegmentOption(string value, string label)
        {
            Value = value ?? string.Empty;
            Label = label ?? value ?? string.Empty;
        }

        public string Value { get; }
        public string Label { get; }
    }

    public sealed class ManagedSegmentInfo
    {
        public ManagedSegmentInfo(IEnumerable<ManagedSegmentOption> segments, ManagedSegmentOption adminOption)
        {
            Segments = segments?.ToList() ?? new List<ManagedSegmentOption>();
            AdminOption = adminOption;
        }

        public IReadOnlyList<ManagedSegmentOption> Segments { get; }
        public ManagedSegmentOption AdminOption { get; }
        public bool IsAdmin => AdminOption != null;

        public IEnumerable<ManagedSegmentOption> EnumerateAll()
        {
            if (AdminOption != null)
                yield return AdminOption;

            foreach (var option in Segments)
                yield return option;
        }
    }

    public static class ManagedSegmentHelper
    {
        private static readonly char[] Separator = { ';', ',', '|' };
        private const string ViewAsAccountSessionKey = "ManagedSegment.ViewAsAccount";
        private const string ViewAsGroupsSessionKey = "ManagedSegment.ViewAsGroups";

        public static bool IsTruthy(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            var lowered = value.Trim();
            return lowered.Equals("true", StringComparison.OrdinalIgnoreCase)
                || lowered.Equals("1", StringComparison.OrdinalIgnoreCase)
                || lowered.Equals("yes", StringComparison.OrdinalIgnoreCase);
        }

        public static ManagedSegmentInfo GetManagedSegmentInfo(IPrincipal principal = null, bool allowViewAsOverride = true)
        {
            return BuildManagedSegmentInfo(principal, null, allowViewAsOverride);
        }

        public static ManagedSegmentInfo GetManagedSegmentInfoForGroups(IEnumerable<string> groupNames)
        {
            return BuildManagedSegmentInfo(null, groupNames, allowViewAsOverride: false);
        }

        public static bool IsAdmin(IPrincipal principal = null)
        {
            return GetManagedSegmentInfo(principal, allowViewAsOverride: false)?.IsAdmin == true;
        }

        public static string GetViewAsAccount()
        {
            var session = HttpContext.Current?.Session;
            if (session == null) return null;

            var account = session[ViewAsAccountSessionKey] as string;
            return string.IsNullOrWhiteSpace(account) ? null : account;
        }

        public static IReadOnlyList<string> GetViewAsGroups()
        {
            var groups = GetViewAsGroupsInternal();
            return groups ?? Array.Empty<string>();
        }

        public static void SetViewAsOverride(string accountName, IEnumerable<string> groupNames)
        {
            var session = HttpContext.Current?.Session;
            if (session == null) return;

            var normalizedGroups = groupNames?
                .Where(g => !string.IsNullOrWhiteSpace(g))
                .Select(g => g.Trim())
                .Where(g => !string.IsNullOrEmpty(g))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(g => g, StringComparer.OrdinalIgnoreCase)
                .ToArray() ?? Array.Empty<string>();

            session[ViewAsGroupsSessionKey] = normalizedGroups;

            if (string.IsNullOrWhiteSpace(accountName))
                session.Remove(ViewAsAccountSessionKey);
            else
                session[ViewAsAccountSessionKey] = accountName.Trim();
        }

        public static void ClearViewAsOverride()
        {
            var session = HttpContext.Current?.Session;
            if (session == null) return;

            session.Remove(ViewAsAccountSessionKey);
            session.Remove(ViewAsGroupsSessionKey);
        }

        private static IEnumerable<string> ResolveGroupNames(IPrincipal principal, IEnumerable<string> explicitGroupNames, bool allowViewAsOverride)
        {
            if (explicitGroupNames != null)
                return explicitGroupNames;

            if (allowViewAsOverride)
            {
                var overrideGroups = GetViewAsGroupsInternal();
                if (overrideGroups != null)
                    return overrideGroups;
            }

            var effectivePrincipal = principal ?? HttpContext.Current?.User ?? Thread.CurrentPrincipal;
            return EnumerateGroupNamesFromPrincipal(effectivePrincipal) ?? Enumerable.Empty<string>();
        }

        private static string[] GetViewAsGroupsInternal()
        {
            var session = HttpContext.Current?.Session;
            if (session == null)
                return null;

            if (session[ViewAsGroupsSessionKey] is string[] groups)
                return groups;

            return null;
        }

        private static ManagedSegmentInfo BuildManagedSegmentInfo(IPrincipal principal, IEnumerable<string> overrideGroupNames, bool allowViewAsOverride)
        {
            var pattern = ConfigurationManager.AppSettings["ManagedSegmentGroupPattern"] ?? @"EUR\app_eur_contar_*";
            var adminGroupsSetting = ConfigurationManager.AppSettings["ManagedSegmentAdminGroups"] ?? string.Empty;
            var adminLabel = ConfigurationManager.AppSettings["ManagedSegmentAdminLabel"] ?? "All segments (admin)";
            var adminValue = ConfigurationManager.AppSettings["ManagedSegmentAdminValue"] ?? string.Empty;

            var adminGroups = adminGroupsSetting
                .Split(Separator, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => !string.IsNullOrEmpty(s))
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var segments = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            bool isAdmin = false;

            var groupNames = ResolveGroupNames(principal, overrideGroupNames, allowViewAsOverride);

            foreach (var groupName in groupNames)
            {
                var normalized = groupName?.Trim();
                if (string.IsNullOrWhiteSpace(normalized))
                    continue;

                if (MatchesPattern(normalized, pattern))
                    segments.Add(normalized);

                if (adminGroups.Count > 0)
                {
                    if (adminGroups.Contains(normalized))
                        isAdmin = true;
                }
                else if (IsDefaultAdminGroup(normalized))
                {
                    isAdmin = true;
                }
            }

            var orderedSegments = segments
                .OrderBy(s => s, StringComparer.OrdinalIgnoreCase)
                .Select(s => new ManagedSegmentOption(s, FormatLabel(s)))
                .ToList();

            ManagedSegmentOption adminOption = null;
            if (isAdmin)
                adminOption = new ManagedSegmentOption(adminValue, adminLabel);

            return new ManagedSegmentInfo(orderedSegments, adminOption);
        }

        public static DataTable BuildOptionsTable(ManagedSegmentInfo info)
        {
            var table = new DataTable();
            table.Columns.Add("value", typeof(string));
            table.Columns.Add("text", typeof(string));

            if (info != null)
            {
                foreach (var option in info.EnumerateAll())
                    table.Rows.Add(option.Value ?? string.Empty, option.Label ?? string.Empty);
            }

            return table;
        }

        public static void PrepareInstructionsForManagedFilter(IDictionary<string, string> instructions)
        {
            if (instructions == null) return;
            instructions["managedSegment"] = "true";
            instructions["type"] = "dropdown";
            instructions["valueField"] = "value";
            instructions["textField"] = "text";
            instructions["query"] = string.Empty;
            instructions["required"] = "true";
        }

        public static string ResolveValue(Dictionary<string, string> requestParameters, string paramName, string defaultValue, ManagedSegmentInfo info)
        {
            if (string.IsNullOrWhiteSpace(paramName))
                return string.Empty;

            if (requestParameters == null)
                requestParameters = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            requestParameters.TryGetValue(paramName, out string rawValue);
            var managedValue = BuildManagedSegmentValue(rawValue, defaultValue, info, out var isAdmin);
            requestParameters[paramName] = managedValue ?? string.Empty;
            requestParameters[paramName + "_admin"] = isAdmin ? "1" : "0";
            return managedValue ?? string.Empty;
        }

        private static string BuildManagedSegmentValue(string currentValue, string defaultValue, ManagedSegmentInfo info, out bool isAdmin)
        {
            isAdmin = info?.IsAdmin == true;

            var values = new List<string>();

            if (info != null)
            {
                foreach (var segment in info.Segments)
                {
                    if (!string.IsNullOrWhiteSpace(segment.Value))
                        values.Add(segment.Value);
                }

                if (isAdmin && info.AdminOption != null && !string.IsNullOrWhiteSpace(info.AdminOption.Value))
                    values.Add(info.AdminOption.Value);
            }

            if (!isAdmin && values.Count == 0)
            {
                if (!string.IsNullOrWhiteSpace(currentValue))
                    values.Add(currentValue);
                else if (!string.IsNullOrWhiteSpace(defaultValue))
                    values.Add(defaultValue);
            }

            if (values.Count == 0)
                return string.Empty;

            var distinct = values
                .Where(v => !string.IsNullOrWhiteSpace(v))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            return distinct.Count > 0 ? string.Join(",", distinct) : string.Empty;
        }

        public static IReadOnlyList<string> GetUserGroupNames(IPrincipal principal = null)
        {
            var targetPrincipal = principal ?? HttpContext.Current?.User ?? Thread.CurrentPrincipal;
            var names = EnumerateGroupNamesFromPrincipal(targetPrincipal)
                .Where(name => !string.IsNullOrWhiteSpace(name))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
                .ToList();

            return names;
        }

        public static IReadOnlyList<string> GetUserGroupNames(string accountName, out string errorMessage)
        {
            errorMessage = null;
            if (string.IsNullOrWhiteSpace(accountName))
            {
                return GetUserGroupNames();
            }

            var domainOverride = ConfigurationManager.AppSettings["ManagedSegmentDirectoryDomain"];
            return LookupGroupNamesForAccount(accountName.Trim(), domainOverride, out errorMessage);
        }

        private static IEnumerable<string> EnumerateGroupNamesFromPrincipal(IPrincipal principal)
        {
            var identity = ResolveIdentity(principal);
            if (identity?.Groups == null)
                yield break;

            foreach (var groupSid in identity.Groups)
            {
                string name = null;
                try
                {
                    name = groupSid.Translate(typeof(NTAccount)).ToString();
                }
                catch (IdentityNotMappedException)
                {
                    continue;
                }
                catch (SystemException)
                {
                    continue;
                }

                if (!string.IsNullOrWhiteSpace(name))
                    yield return name;
            }
        }

        private static IReadOnlyList<string> LookupGroupNamesForAccount(string accountName, string domainOverride, out string errorMessage)
        {
            errorMessage = null;
            var groups = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            PrincipalContext context = null;

            try
            {
                var identityInfo = ParseAccountIdentity(accountName, domainOverride);
                var domain = identityInfo.domain ?? domainOverride;

                context = !string.IsNullOrWhiteSpace(domain)
                    ? new PrincipalContext(ContextType.Domain, domain)
                    : new PrincipalContext(ContextType.Domain);

                using (var user = UserPrincipal.FindByIdentity(context, identityInfo.type, identityInfo.value))
                {
                    if (user == null)
                    {
                        errorMessage = $"User '{accountName}' was not found in directory.";
                        return new List<string>();
                    }

                    using (var authorizationGroups = user.GetAuthorizationGroups())
                    {
                        foreach (var principal in authorizationGroups)
                        {
                            if (principal?.Sid == null)
                                continue;

                            string groupName = null;
                            try
                            {
                                groupName = principal.Sid.Translate(typeof(NTAccount)).ToString();
                            }
                            catch (IdentityNotMappedException)
                            {
                                continue;
                            }
                            catch (SystemException)
                            {
                                continue;
                            }

                            if (!string.IsNullOrWhiteSpace(groupName))
                                groups.Add(groupName);
                        }
                    }
                }
            }
            catch (PrincipalServerDownException ex)
            {
                errorMessage = ex.Message;
            }
            catch (PrincipalOperationException ex)
            {
                errorMessage = ex.Message;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
            finally
            {
                context?.Dispose();
            }

            return groups.OrderBy(name => name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static (IdentityType type, string value, string domain) ParseAccountIdentity(string accountName, string domainOverride)
        {
            if (string.IsNullOrWhiteSpace(accountName))
                return (IdentityType.SamAccountName, string.Empty, domainOverride);

            var trimmed = accountName.Trim();

            if (!string.IsNullOrWhiteSpace(domainOverride))
            {
                var lastSeparator = trimmed.LastIndexOf('\\');
                var normalized = lastSeparator >= 0 && lastSeparator < trimmed.Length - 1
                    ? trimmed.Substring(lastSeparator + 1)
                    : trimmed;
                return (IdentityType.SamAccountName, normalized, domainOverride);
            }

            var atIndex = trimmed.IndexOf('@');
            if (atIndex > 0 && atIndex < trimmed.Length - 1)
            {
                var domain = trimmed.Substring(atIndex + 1);
                return (IdentityType.UserPrincipalName, trimmed, domain);
            }

            var slashIndex = trimmed.IndexOf('\\');
            if (slashIndex > -1 && slashIndex < trimmed.Length - 1)
            {
                var domain = trimmed.Substring(0, slashIndex);
                var value = trimmed.Substring(slashIndex + 1);
                return (IdentityType.SamAccountName, value, domain);
            }

            return (IdentityType.SamAccountName, trimmed, domainOverride);
        }

        private static WindowsIdentity ResolveIdentity(IPrincipal principal)
        {
            if (principal is WindowsPrincipal wp && wp.Identity is WindowsIdentity wi)
                return wi;

            var httpIdentity = HttpContext.Current?.Request?.LogonUserIdentity;
            if (httpIdentity != null)
                return httpIdentity;

            return WindowsIdentity.GetCurrent();
        }

        private static bool MatchesPattern(string value, string pattern)
        {
            if (string.IsNullOrWhiteSpace(pattern) || string.IsNullOrWhiteSpace(value))
                return false;

            pattern = pattern.Trim();
            if (pattern.EndsWith("*", StringComparison.Ordinal))
            {
                var prefix = pattern.Substring(0, pattern.Length - 1);
                return value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase);
            }

            return value.Equals(pattern, StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsDefaultAdminGroup(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return value.EndsWith("_admin", StringComparison.OrdinalIgnoreCase)
                || value.EndsWith("-admin", StringComparison.OrdinalIgnoreCase);
        }

        private static string FormatLabel(string group)
        {
            if (string.IsNullOrWhiteSpace(group))
                return string.Empty;

            var idx = group.IndexOf('\\');
            return idx >= 0 && idx < group.Length - 1 ? group.Substring(idx + 1) : group;
        }
    }
}

