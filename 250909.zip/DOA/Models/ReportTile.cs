﻿namespace Core.Models
{
    public class ReportTile
    {
        public string Name { get; set; }
        public bool IsFavorite { get; set; }
        // Ide később jöhetnek további tulajdonságok, pl. leírás
        // public string Description { get; set; }
    }
}
